# Karar kaydı

Belirsiz noktalar burada çözülür; çözülmeden ilgili kod yazılmaz (§32). Claude Code yeni bir belirsizlik bulursa satır ekler ve durur.

| # | Karar | Önerilen başlangıç | Kesinleştiren | Durum | Kanıt / tarih |
| --- | --- | --- | --- | --- | --- |
| K-01 | Teknoloji yığını ve sürümler | CLAUDE.md'deki öneri | Teknik sorumlu | Açık | |
| K-02 | Pilot sektör profilleri | `genel` + 2 profil | Ürün sahibi + alan uzmanı | Açık | |
| K-03 | Profil sınıflandırması (NACE düzeyi, çok faaliyetli kurum kuralı) | NACE bölüm düzeyi; tesis bazlı profil | Alan uzmanı | Açık | |
| K-04 | Hesap otoritesi | GHG Protocol tabanlı sürümlü yöntemler | Alan uzmanı | Açık | |
| K-05 | Faktör kaynakları ve lisansları | Resmî / tedarikçi / lisanslı kaynaklar | Yöntem ve lisans sorumlusu | Açık | |
| K-06 | Ulusal ETS: ikincil mevzuat, MRV kılavuzu, tahsis kuralları | Resmî kaynaktan doğrulanana kadar `review_required` | Raporlama uzmanı | Açık | |
| K-07 | CBAM'de menşe ülkede ödenen karbon fiyatının kanıt formatı | AB güncel uygulama mevzuatı | Raporlama uzmanı | Açık | |
| K-08 | TSRS uygulanabilirliği | Güncel KGK kararı + kurum profili | Raporlama uzmanı | Açık | |
| K-09 | Green Kaizen ve saha verisi için KVKK | Birim düzeyinde toplulaştırma | Hukuk + çalışan temsilcisi | Açık | |
| K-10 | Memnuniyet / bağlılık ölçüm yöntemi | Anonim, çeyreklik kısa anket | İK | Açık | |
| K-11 | Gölge karbon fiyatını belirleyen ve güncelleme sıklığı | Finans + sürdürülebilirlik, yıllık | Yönetim | Açık | |
| K-12 | Sözlük ve GRI/ISO içerik kullanım hakları | Bağlantı + özgün kısa açıklama | Hukuk/lisans | Açık | |
| K-13 | Veri saklama süresi ve bölgesi | Sözleşmeye uygun en düşük gerekli saklama | Güvenlik + hukuk | Açık | |
| K-14 | Ortak veri şablonu için sektör dernekleri / OSB / üniversite iş birliği | Kazanılmış kabul edilmez | Ürün sahibi | Açık | |
| K-15 | Fon haritası kaynakları | Yalnız resmî çağrı metinleri | İçerik sorumlusu | Açık | |
